<?php 
 $con = mysqli_connect('localhost','root','','canvas_school');
?>