 <script src="src/js/vendors.min.js"></script>
  <script src="src/js/pages/chat-popup.js"></script>
    <script src="assets/icons/feather-icons/feather.min.js"></script>  <script src="assets/vendor_components/jquery-steps-master/build/jquery.steps.js"></script>
    <script src="assets/vendor_components/jquery-validation-1.17.0/dist/jquery.validate.min.js"></script>
    <script src="assets/vendor_components/sweetalert/sweetalert.min.js"></script>
  <script src="src/js/pages/data-table.js"></script>
  <script src="assets/vendor_components/datatable/datatables.min.js"></script>
  <!-- InvestX App -->
  <script src="src/js/demo.js"></script>
  <script src="src/js/template.js"></script>
  
    <script src="src/js/pages/steps.js"></script>