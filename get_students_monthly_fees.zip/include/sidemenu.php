  <aside class="main-sidebar">
  	<section class="sidebar position-relative"> 
  		<div class="multinav">
  			<div class="multinav-scroll" style="height: 97%;">	
  				<ul class="sidebar-menu" data-widget="tree">
  					<li><a href="dashboard.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Dashboard</a></li>
  				
          <li class="treeview">
              <a href="#">
                <i data-feather="grid"></i>
                <span>Students</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-right pull-right"></i>
                </span>
              </a>          
              <ul class="treeview-menu">          
                <li><a href="add_students.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Add Students</a></li>
                <li><a href="table.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Table</a></li>
              </ul>
            </li> 
            <li class="treeview">
              <a href="#">
                <i data-feather="grid"></i>
                <span>Fees</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-right pull-right"></i>
                </span>
              </a>          
              <ul class="treeview-menu">          
                <li><a href="collect_adm_fees.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Collect Admission Fees</a></li>
                <li><a href="collect_monthly_fees.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Collect Monthly Fees</a></li>
              </ul>
            </li> 
            <li class="treeview">
              <a href="#">
                <i data-feather="grid"></i>
                <span>Masters</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-right pull-right"></i>
                </span>
              </a>          
              <ul class="treeview-menu">          
                <li><a href="sessions.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Sessions</a></li>
                <li><a href="class.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Class</a></li>
                <li><a href="monthly_fees_master.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Monthly Fees</a></li>
                <li><a href="admission_fees_master.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Admission Fees</a></li>
                
              </ul>
            </li> 
         <li><a href="logout.php"><i class="icon-Commit"><span class="path1"></span><span class="path2"></span></i>Logout</a></li>
       </div>
     </div>
   </section>
 </aside>